# Supervisor notebooks

Open 00_Project_Overview.ipynb first, then chapters 01–07 in order. HTML copies provide the same saved outputs without Jupyter.

Run from the project root with `.venv/Scripts/python.exe -m scripts.build_supervisor_notebooks` to regenerate from pinned evidence. Individual notebooks run from this folder or the project root. Dependencies: pandas, matplotlib, scikit-learn and Jupyter/nbformat. No Google credentials or raw customer data are included in this folder.

These notebooks replay recorded aggregate evidence. Full training and source-cleaning implementations remain in scripts and dbt, with exact paths in each chapter. Rebuilding this pack does not retrain or publish models.
